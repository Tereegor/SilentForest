# import os
# import sys
# import pygame
#
# pygame.init()
# pygame.display.set_caption('Герой двигается')
# size = width, height = 300, 300
# screen = pygame.display.set_mode(size)
# fps = 30
# plenty = [0, 0]
# screen.fill('white')
#
#
# def load_image(name, colorkey=None):
#     fullname = os.path.join('data', name)
#     if not os.path.isfile(fullname):
#         print(f"Файл с изображением '{fullname}' не найден")
#         sys.exit()
#     image = pygame.image.load(fullname)
#     if colorkey is not None:
#         image = image.convert()
#         if colorkey == -1:
#             colorkey = image.get_at((0, 0))
#         image.set_colorkey(colorkey)
#     else:
#         image = image.convert_alpha()
#     return image
#
#
# all_sprites = pygame.sprite.Group()
# clock = pygame.time.Clock()
#
# cursor = pygame.sprite.Sprite(all_sprites)
# cursor.image = load_image('Creature.png')
# cursor.rect = cursor.image.get_rect()
#
# running = True
# while running:
#     for event in pygame.event.get():
#         if event.type == pygame.QUIT:
#             running = False
#         keys = pygame.key.get_pressed()
#         if keys[pygame.K_LEFT] == 1:
#             plenty[0] -= 10
#             cursor.rect.x, cursor.rect.y = plenty[0], plenty[1]
#             screen.fill('white')
#             all_sprites.draw(screen)
#         if keys[pygame.K_RIGHT] == 1:
#             plenty[0] += 10
#             cursor.rect.x, cursor.rect.y = plenty[0], plenty[1]
#             screen.fill('white')
#             all_sprites.draw(screen)
#         if keys[pygame.K_UP] == 1:
#             plenty[1] -= 10
#             cursor.rect.x, cursor.rect.y = plenty[0], plenty[1]
#             screen.fill('white')
#             all_sprites.draw(screen)
#         if keys[pygame.K_DOWN] == 1:
#             plenty[1] += 10
#             cursor.rect.x, cursor.rect.y = plenty[0], plenty[1]
#             screen.fill('white')
#             all_sprites.draw(screen)
#     pygame.display.flip()
#     all_sprites.draw(screen)
#     clock.tick(fps)
#
# pygame.quit()
# import pygame
#
# if __name__ == '__main__':
#     pygame.init()
#     pygame.display.set_caption('Вентилятор')
#     size = width, height = 201, 201
#     screen = pygame.display.set_mode(size)
#     running = True
#     fps = 60
#     plus = 40000
#     screen.fill('black')
#     clock = pygame.time.Clock()
#     pygame.time.set_timer(plus, 10)
#     plenty_1 = [80, 30, 120, 30]
#     plenty_2 = [171, 122, 152, 155]
#     plenty_3 = [30, 122, 48, 155]
#     pygame.draw.circle(screen, (pygame.Color('white')), (100, 100), 20)
#     pygame.draw.polygon(screen, (pygame.Color('white')),
#                         [(100, 100), (plenty_1[0], plenty_1[1]), (plenty_1[2], plenty_1[3])])
#     pygame.draw.polygon(screen, (pygame.Color('white')),
#                         [(100, 100), (plenty_2[0], plenty_2[1]), (plenty_2[2], plenty_2[3])])
#     pygame.draw.polygon(screen, (pygame.Color('white')),
#                         [(100, 100), (plenty_3[0], plenty_3[1]), (plenty_3[2], plenty_3[3])])
#     pygame.draw.circle(screen, pygame.Color('white'), (100, 100), 76, 4)
#     while running:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 running = False
#             if event.type == pygame.MOUSEBUTTONDOWN:
#                 if event.button == 1:
#                     if plenty_1[0] <= 100:
#                         plenty_1[0] += 1
#                         plenty_1[1] -= 1
#                         plenty_1[2] += 1
#                         plenty_1[3] += 1
#                         screen.fill('black')
#                         pygame.draw.circle(screen, (pygame.Color('white')), (100, 100), 20)
#                         pygame.draw.polygon(screen, (pygame.Color('white')),
#                                         [(100, 100), (plenty_1[0], plenty_1[1]), (plenty_1[2], plenty_1[3])])
#                         pygame.draw.polygon(screen, (pygame.Color('white')), [(100, 100), (175, 122), (160, 155)])
#                         pygame.draw.polygon(screen, (pygame.Color('white')), [(100, 100), (30, 122), (45, 155)])
#                     else:
#                         plenty_1[0] += 1
#                         plenty_1[1] += 1
#                         plenty_1[2] += 1
#                         plenty_1[3] += 1
#                         screen.fill('black')
#                         pygame.draw.circle(screen, (pygame.Color('white')), (100, 100), 20)
#                         pygame.draw.polygon(screen, (pygame.Color('white')),
#                                         [(100, 100), (plenty_1[0], plenty_1[1]), (plenty_1[2], plenty_1[3])])
#                         pygame.draw.polygon(screen, (pygame.Color('white')), [(100, 100), (175, 122), (160, 155)])
#                         pygame.draw.polygon(screen, (pygame.Color('white')), [(100, 100), (30, 122), (45, 155)])
#         pygame.display.flip()
#         clock.tick(fps)
#     pygame.display.flip()
#     clock.tick(fps)
# pygame.quit()

# import csv
#
# plenty_words = []
# plenty = []
# plenty_achievements = [0]
# plenty_index = [0]
# counter = 1
# with open('alpha_oriona.csv', encoding="utf8") as csvfile:
#     reader = csv.reader(csvfile, delimiter=';', quotechar='"')
#     for index, row in enumerate(reader):
#         plenty_words.append(row)
#         if index >= 1:
#             plenty.append(row[2])
#         if len(plenty) >= 2:
#             if int(plenty[-2]) >= int(plenty[-1]):
#                 counter += 1
#             if int(plenty[-1]) > int(plenty[-2]) and counter > plenty_achievements[0]:
#                 plenty_achievements[0] = counter
#                 plenty_index[0] = index - counter
#                 counter = 1
#             elif int(plenty[-1]) > int(plenty[-2]) and counter <= plenty_achievements[0]:
#                 counter = 1
#     if counter > plenty_achievements[0]:
#         plenty_achievements[0] = counter
#         plenty_index[0] = index - counter + 1
# say = plenty_index[0]
# with open('result.txt', 'w', newline='', encoding="utf8") as csvfile:
#     csvfile.write(str(plenty_achievements[0]) + '\n')
#     csvfile.write(plenty_words[say][0] + ' ')
#     csvfile.write(plenty_words[say][1])
# import pygame
#
#
# class Board:
#     def __init__(self, width, height):
#         self.width = width
#         self.height = height
#         self.board = [[0] * width for _ in range(height)]
#         # значения по умолчанию
#         self.left = 10
#         self.top = 10
#         self.cell_size = 30
#
#     def set_view(self, left, top, cell_size):
#         self.left = left
#         self.top = top
#         self.cell_size = cell_size
#
#     def render(self, screen):
#         for i in range(0, self.width):
#             for j in range(0, self.height):
#                 pygame.draw.rect(screen, pygame.Color('white'),
#                                  (i * self.cell_size + self.left, j * self.cell_size + self.top, self.cell_size,
#                                   self.cell_size),
#                                  1)
#
#     def get_click(self, mouse_pos):
#         self.get_cell(mouse_pos)
#         self.on_click(mouse_pos)
#
#     def get_cell(self, mouse_pos):
#         coords_x, coords_y = mouse_pos
#         starts_len = coords_x - self.left
#         starts_height = coords_y - self.top
#         coords_len = starts_len // self.cell_size
#         coords_height = starts_height // self.cell_size
#         if coords_len in range(self.width) and coords_height in range(self.height):
#             return coords_len, coords_height
#         else:
#             return None
#
#     def on_click(self, cell_coords):
#         self.coordinates = self.get_cell(cell_coords)
#
#     def draw(self, screen):
#         if self.coordinates:
#             number = 0
#             for i in range(self.width):
#                 digit_x = self.left + number * self.cell_size
#                 digit_y = self.top + self.coordinates[1] * self.cell_size
#                 if self.board[number][self.coordinates[1]] == 0 and number != self.coordinates[0]:
#                     pygame.draw.rect(screen, pygame.Color('white'),
#                                      (digit_x, digit_y, self.cell_size, self.cell_size), 0)
#                     self.board[number][self.coordinates[1]] = 1
#                 elif self.board[number][self.coordinates[1]] == 1 and number != self.coordinates[0]:
#                     pygame.draw.rect(screen, pygame.Color('black'),
#                                      (digit_x, digit_y, self.cell_size, self.cell_size), 0)
#                     self.board[number][self.coordinates[1]] = 0
#                 number += 1
#             counter = 0
#             for j in range(self.height):
#                 digit_x = self.left + self.coordinates[0] * self.cell_size
#                 digit_y = self.top + self.cell_size * counter
#                 if self.board[self.coordinates[0]][counter] == 0:
#                     pygame.draw.rect(screen, pygame.Color('white'),
#                                      (digit_x, digit_y, self.cell_size, self.cell_size), 0)
#                     self.board[self.coordinates[0]][counter] = 1
#                 elif self.board[self.coordinates[0]][counter] == 1:
#                     pygame.draw.rect(screen, pygame.Color('black'),
#                                      (digit_x, digit_y, self.cell_size, self.cell_size), 0)
#                     self.board[self.coordinates[0]][counter] = 0
#                 counter += 1
#
#     def color_change(self, screen):
#         if self.coordinates:
#             digit_x = self.left + self.coordinates[0] * self.cell_size
#             digit_y = self.top + self.coordinates[1] * self.cell_size
#             if self.board[self.coordinates[0]][self.coordinates[1]] == 0 and plenty_priority[0] == 0:
#                 pygame.draw.line(screen, pygame.Color('blue'),
#                                  [digit_x + 2, digit_y + 2],
#                                  [digit_x - 4 + self.cell_size, digit_y - 4 + self.cell_size], 2)
#                 pygame.draw.line(screen, pygame.Color('blue'),
#                                  [digit_x + 2, digit_y + self.cell_size - 2],
#                                  [digit_x + self.cell_size - 2, digit_y + 2], 2)
#                 self.board[self.coordinates[0]][self.coordinates[1]] = 1
#                 plenty_priority[0] = 1
#             elif self.board[self.coordinates[0]][self.coordinates[1]] == 0 and plenty_priority[0] == 1:
#                 pygame.draw.circle(screen, pygame.Color('red'),
#                                    (digit_x + 0.5 * self.cell_size, digit_y + 0.5 * self.cell_size),
#                                    self.cell_size * 0.5 - 2, 2)
#                 self.board[self.coordinates[0]][self.coordinates[1]] = 1
#                 plenty_priority[0] = 0
#
#
# plenty_priority = [0]
#
#
# def main():
#     pygame.init()
#     size = 500, 500
#     screen = pygame.display.set_mode(size)
#     screen.fill('black')
#     pygame.display.set_caption('Инициализация игры')
#
#     board = Board(5, 5)
#     board.set_view(40, 60, 100)
#     running = True
#     while running:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 running = False
#             if event.type == pygame.MOUSEBUTTONUP:
#                 board.get_click(event.pos)
#                 # board.draw(screen)
#                 board.color_change(screen)
#         board.render(screen)
#         pygame.display.flip()
#     pygame.quit()
#
#
# # if __name__ == '__main__':

# import pygame
# plenty = [1]
#
# if __name__ == '__main__':
#     pygame.init()
#     pygame.display.set_caption('Шарики')
#     size = width, height = 200, 200
#     screen = pygame.display.set_mode(size)
#     running = True
#     fps = 60
#     screen.fill('black')
#     while running:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 running = False
#             if event.type == pygame.VIDEOEXPOSE:
#                 screen.fill('black')
#                 font = pygame.font.Font(None, 100)
#                 text = font.render(str(plenty[0]), True, ('red'))
#                 text_x = width // 2 - text.get_width() // 2
#                 text_y = height // 2 - text.get_height() // 2
#                 text_w = text.get_width()
#                 text_h = text.get_height()
#                 screen.blit(text, (text_x, text_y))
#                 plenty[0] += 1
#
#         pygame.display.flip()
#     pygame.quit()
# import os
# import sys
# import pygame
# import random
#
# pygame.init()
# pygame.display.set_caption('Boom them all')
# size = width, height = 500, 500
# screen = pygame.display.set_mode(size)
# fps = 100
# plenty = []
# screen.fill('black')
#
#
# def load_image(name, colorkey=None):
#     fullname = os.path.join('data', name)
#     if not os.path.isfile(fullname):
#         print(f"Файл с изображением '{fullname}' не найден")
#         sys.exit()
#     image = pygame.image.load(fullname)
#     if colorkey is not None:
#         image = image.convert()
#         if colorkey == -1:
#             colorkey = image.get_at((0, 0))
#         image.set_colorkey(colorkey)
#     else:
#         image = image.convert_alpha()
#     return image
#
#
# clock = pygame.time.Clock()
# all_sprites = pygame.sprite.Group()
#
# # создадим спрайт
# sprite = pygame.sprite.Sprite()
#
#
# class Bomb(pygame.sprite.Sprite):
#     image = load_image("Bomba.png")
#     image_boom = load_image("Finally.png")
#
#     def __init__(self, group):
#         # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
#         # Это очень важно !!!
#         super().__init__(group)
#         self.image = Bomb.image
#         self.rect = self.image.get_rect()
#         self.rect.x = random.randrange(width)
#         self.rect.y = random.randrange(height)
#
#     def update(self, *args):
#         if args and args[0].type == pygame.MOUSEBUTTONUP and \
#                 self.rect.collidepoint(args[0].pos):
#             self.image = self.image_boom
#
#
#
# screen.fill('black')
# for i in range(50):
#     Bomb(all_sprites)
# running = True
# while running:
#     for event in pygame.event.get():
#         if event.type == pygame.QUIT:
#             running = False
#         screen.fill('black')
#         all_sprites.draw(screen)
#         all_sprites.update(event)
#     pygame.display.flip()
#     clock.tick(fps)
#
# pygame.quit()
# import pygame
# plenty = [1]
#
# if __name__ == '__main__':
#     pygame.init()
#     pygame.display.set_caption('Шарики')
#     size = width, height = 200, 200
#     screen = pygame.display.set_mode(size)
#     running = True
#     fps = 60
#     screen.fill('black')
#     font = pygame.font.Font(None, 100)
#     text = font.render(str(plenty[0]), True, 'red')
#     text_x = width // 2 - text.get_width() // 2
#     text_y = height // 2 - text.get_height() // 2
#     text_w = text.get_width()
#     text_h = text.get_height()
#     screen.blit(text, (text_x, text_y))
#     plenty[0] += 1
#     while running:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 running = False
#             if event.type == pygame.WINDOWMINIMIZED:
#                 screen.fill('black')
#                 font = pygame.font.Font(None, 100)
#                 text = font.render(str(plenty[0]), True, 'red')
#                 text_x = width // 2 - text.get_width() // 2
#                 text_y = height // 2 - text.get_height() // 2
#                 text_w = text.get_width()
#                 text_h = text.get_height()
#                 screen.blit(text, (text_x, text_y))
#                 plenty[0] += 1
#
#         pygame.display.flip()
#     pygame.quit()
# import pygame
#
#
# class Board:
#     def __init__(self):
#         self.left = 10
#         self.top = 10
#         self.cell_size = 30
#
#     def set_view(self, cell_size):
#         self.cell_size = cell_size
#         self.width = 480 // cell_size
#         self.height = 480 // cell_size
#         self.board = [[0] * self.width for _ in range(self.height)]
#
#     def render(self, screen):
#         for i in range(0, self.width):
#             for j in range(0, self.height):
#                 pygame.draw.rect(screen, pygame.Color('white'),
#                                  (i * self.cell_size + self.left, j * self.cell_size + self.top, self.cell_size,
#                                   self.cell_size),
#                                  1)
#
#     def get_click(self, mouse_pos):
#         self.get_cell(mouse_pos)
#         self.on_click(mouse_pos)
#
#     def get_cell(self, mouse_pos):
#         coords_x, coords_y = mouse_pos
#         starts_len = coords_x - self.left
#         starts_height = coords_y - self.top
#         coords_len = starts_len // self.cell_size
#         coords_height = starts_height // self.cell_size
#         if coords_len in range(self.width) and coords_height in range(self.height):
#             return coords_len, coords_height
#         else:
#             return None
#
#     def on_click(self, cell_coords):
#         self.coordinates = self.get_cell(cell_coords)
#
#     def draw(self, screen):
#         if self.coordinates:
#             number = 0
#             for i in range(self.width):
#                 digit_x = self.left + number * self.cell_size
#                 digit_y = self.top + self.coordinates[1] * self.cell_size
#                 if self.board[number][self.coordinates[1]] == 0 and number != self.coordinates[0]:
#                     pygame.draw.rect(screen, pygame.Color('white'),
#                                      (digit_x, digit_y, self.cell_size, self.cell_size), 0)
#                     self.board[number][self.coordinates[1]] = 1
#                 elif self.board[number][self.coordinates[1]] == 1 and number != self.coordinates[0]:
#                     pygame.draw.rect(screen, pygame.Color('black'),
#                                      (digit_x, digit_y, self.cell_size, self.cell_size), 0)
#                     self.board[number][self.coordinates[1]] = 0
#                 number += 1
#             counter = 0
#             for j in range(self.height):
#                 digit_x = self.left + self.coordinates[0] * self.cell_size
#                 digit_y = self.top + self.cell_size * counter
#                 if self.board[self.coordinates[0]][counter] == 0:
#                     pygame.draw.rect(screen, pygame.Color('white'),
#                                      (digit_x, digit_y, self.cell_size, self.cell_size), 0)
#                     self.board[self.coordinates[0]][counter] = 1
#                 elif self.board[self.coordinates[0]][counter] == 1:
#                     pygame.draw.rect(screen, pygame.Color('black'),
#                                      (digit_x, digit_y, self.cell_size, self.cell_size), 0)
#                     self.board[self.coordinates[0]][counter] = 0
#                 counter += 1
#
#     def color_change(self, screen):
#         if self.coordinates:
#             digit_x = self.left + self.coordinates[0] * self.cell_size
#             digit_y = self.top + self.coordinates[1] * self.cell_size
#             if self.board[self.coordinates[0]][self.coordinates[1]] == 0 and plenty_priority[0] == 0:
#                 pygame.draw.line(screen, pygame.Color('blue'),
#                                  [digit_x + 2, digit_y + 2],
#                                  [digit_x - 4 + self.cell_size, digit_y - 4 + self.cell_size], 2)
#                 pygame.draw.line(screen, pygame.Color('blue'),
#                                  [digit_x + 2, digit_y + self.cell_size - 2],
#                                  [digit_x + self.cell_size - 2, digit_y + 2], 2)
#                 self.board[self.coordinates[0]][self.coordinates[1]] = 1
#                 plenty_priority[0] = 1
#             elif self.board[self.coordinates[0]][self.coordinates[1]] == 0 and plenty_priority[0] == 1:
#                 pygame.draw.circle(screen, pygame.Color('red'),
#                                    (digit_x + 0.5 * self.cell_size, digit_y + 0.5 * self.cell_size),
#                                    self.cell_size * 0.5 - 2, 2)
#                 self.board[self.coordinates[0]][self.coordinates[1]] = 1
#                 plenty_priority[0] = 0
#
#
# plenty_priority = [0]
#
#
# def main():
#     pygame.init()
#     size = 500, 500
#     screen = pygame.display.set_mode(size)
#     screen.fill('black')
#     pygame.display.set_caption('Инициализация игры')
#
#     board = Board()
#     board.set_view(30)
#     running = True
#     while running:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 running = False
#             if event.type == pygame.MOUSEBUTTONUP:
#                 board.get_click(event.pos)
#                 board.color_change(screen)
#         board.render(screen)
#         pygame.display.flip()
#     pygame.quit()
#
#
# if __name__ == '__main__':
#     main()
# import pygame
# import random
#
# digit = int(input())
#
#
# class Board:
#     def __init__(self):
#         self.left = 10
#         self.top = 10
#         self.cell_size = 30
#
#     def set_view(self, cell_size):
#         self.cell_size = cell_size
#         self.width = cell_size * digit
#         self.height = cell_size * digit
#         self.board = [[0] * digit for _ in range(digit)]
#
#     def render(self, screen):
#         for i in range(0, digit):
#             for j in range(0, digit):
#                 pygame.draw.rect(screen, pygame.Color('white'),
#                                  (i * self.cell_size + self.left, j * self.cell_size + self.top, self.cell_size,
#                                   self.cell_size),
#                                  1)
#
#     def color(self):
#         for i in range(digit):
#             for j in range(digit):
#                 number = random.randrange(0, 2)
#                 self.board[i][j] = number
#
#     def filling(self, screen):
#         for i in range(0, digit):
#             for j in range(0, digit):
#                 if self.board[i][j] == 1:
#                     pygame.draw.circle(screen, pygame.Color('red'),
#                                        (i * self.cell_size + self.left + 0.5 * self.cell_size,
#                                         j * self.cell_size + self.top + 0.5 * self.cell_size), self.cell_size / 2 - 1)
#                 elif self.board[i][j] == 0:
#                     pygame.draw.circle(screen, pygame.Color('blue'),
#                                        (i * self.cell_size + self.left + 0.5 * self.cell_size,
#                                         j * self.cell_size + self.top + 0.5 * self.cell_size), self.cell_size / 2 - 1)
#
#     def draw(self, screen):
#         if self.coordinates and plenty_motion[0] == 1:
#             for i in range(digit):
#                 digit_x = self.left + i * self.cell_size
#                 digit_y = self.top + self.coordinates[1] * self.cell_size
#                 if self.board[i][self.coordinates[1]] == 0 and i != self.coordinates[0]:
#                     pygame.draw.circle(screen, pygame.Color('red'),
#                                        (digit_x + self.cell_size / 2, digit_y + self.cell_size / 2),
#                                        self.cell_size / 2 - 1)
#                     self.board[i][self.coordinates[1]] = 1
#             for j in range(digit):
#                 digit_x = self.left + self.coordinates[0] * self.cell_size
#                 digit_y = self.top + self.cell_size * j
#                 if self.board[self.coordinates[0]][j] == 0:
#                     pygame.draw.circle(screen, pygame.Color('red'),
#                                        (digit_x + self.cell_size / 2, digit_y + self.cell_size / 2),
#                                        self.cell_size / 2 - 1)
#                     self.board[self.coordinates[0]][j] = 1
#             plenty_motion[0] = 0
#         elif self.coordinates and plenty_motion[0] == 0:
#             for i in range(digit):
#                 digit_x = self.left + i * self.cell_size
#                 digit_y = self.top + self.coordinates[1] * self.cell_size
#                 if self.board[i][self.coordinates[1]] == 1 and i != self.coordinates[0]:
#                     pygame.draw.circle(screen, pygame.Color('blue'),
#                                        (digit_x + self.cell_size / 2, digit_y + self.cell_size / 2),
#                                        self.cell_size / 2 - 1)
#                     self.board[i][self.coordinates[1]] = 0
#             for j in range(digit):
#                 digit_x = self.left + self.coordinates[0] * self.cell_size
#                 digit_y = self.top + self.cell_size * j
#                 if self.board[self.coordinates[0]][j] == 1:
#                     pygame.draw.circle(screen, pygame.Color('blue'),
#                                        (digit_x + self.cell_size / 2, digit_y + self.cell_size / 2),
#                                        self.cell_size / 2 - 1)
#                     self.board[self.coordinates[0]][j] = 0
#             plenty_motion[0] = 1
#
#     def get_click(self, mouse_pos):
#         self.get_cell(mouse_pos)
#         self.on_click(mouse_pos)
#
#     def get_cell(self, mouse_pos):
#         coords_x, coords_y = mouse_pos
#         starts_len = coords_x - self.left
#         starts_height = coords_y - self.top
#         coords_len = starts_len // self.cell_size
#         coords_height = starts_height // self.cell_size
#         if coords_len in range(self.width) and coords_height in range(self.height):
#             return coords_len, coords_height
#         else:
#             return None
#
#     def on_click(self, cell_coords):
#         self.coordinates = self.get_cell(cell_coords)
#
#
# plenty_motion = [1]
#
#
# def main():
#     pygame.init()
#     size = 500, 500
#     screen = pygame.display.set_mode(size)
#     screen.fill('black')
#     pygame.display.set_caption('Инициализация игры')
#
#     board = Board()
#     board.set_view(30)
#     board.color()
#     board.filling(screen)
#     running = True
#     while running:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 running = False
#             if event.type == pygame.MOUSEBUTTONUP:
#                 board.get_click(event.pos)
#                 board.draw(screen)
#         board.render(screen)
#         pygame.display.flip()
#     pygame.quit()
#
#
# if __name__ == '__main__':
#     main()
# import os
# import sys
# import pygame
# import random
#
# pygame.init()
# pygame.display.set_caption('Boom them all')
# size = width, height = 500, 500
# screen = pygame.display.set_mode(size)
# fps = 100
# plenty = []
# screen.fill('black')
#
#
# def load_image(name, colorkey=None):
#     fullname = os.path.join('data', name)
#     if not os.path.isfile(fullname):
#         print(f"Файл с изображением '{fullname}' не найден")
#         sys.exit()
#     image = pygame.image.load(fullname)
#     if colorkey is not None:
#         image = image.convert()
#         if colorkey == -1:
#             colorkey = image.get_at((0, 0))
#         image.set_colorkey(colorkey)
#     else:
#         image = image.convert_alpha()
#     return image
#
#
# clock = pygame.time.Clock()
# all_sprites = pygame.sprite.Group()
#
# # создадим спрайт
# sprite = pygame.sprite.Sprite()
#
#
# class Bomb(pygame.sprite.Sprite):
#     image = load_image("Bomba.png")
#     image_boom = load_image("Finally.png")
#
#     def __init__(self, group):
#         # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
#         # Это очень важно !!!
#         super().__init__(group)
#         self.image = Bomb.image
#         self.rect = self.image.get_rect()
#         self.rect.x = random.randrange(width)
#         self.rect.y = random.randrange(height)
#
#     def update(self, *args):
#         if args and args[0].type == pygame.MOUSEBUTTONUP and \
#                 self.rect.collidepoint(args[0].pos):
#             self.image = self.image_boom
#
#
# screen.fill('black')
# for i in range(50):
#     Bomb(all_sprites)
# running = True
# while running:
#     for event in pygame.event.get():
#         if event.type == pygame.QUIT:
#             running = False
#         screen.fill('black')
#         all_sprites.draw(screen)
#         all_sprites.update(event)
#     pygame.display.flip()
#     clock.tick(fps)
#
# pygame.quit()
# class LittleBell:
#
#     def sound(self):
#         print('ding')
#
#
# class BigBell:
#     def __init__(self):
#         self.numder = 0
#
#     def sound(self):
#         if self.numder % 2 == 0:
#             print('ding')
#             self.numder += 1
#         else:
#             print('dong')
#             self.numder += 1
#
#
# class BellTower:
#     def __init__(self, *args):
#         self.plenty_variation = []
#         if args:
#             for element in args:
#                 self.plenty_variation.append(element)
#
#     def append(self, name):
#         self.plenty_variation.append(name)
#
#     def sound(self):
#         number = 0
#         if len(self.plenty_variation) != 0:
#             for element in self.plenty_variation:
#                 name = element
#                 name.sound()
#                 number += 1
#         print('...')
#
#
# b_tower1 = BellTower(*[LittleBell(), BigBell()])
# b_tower2 = BellTower(*[LittleBell()])
# b_tower3 = BellTower(BigBell())
# b_tower4 = BellTower()
# b_tower1.sound()
# b_tower2.sound()
# b_tower3.sound()
# b_tower4.sound()
# b_tower4.append(BigBell())
# b_tower2.append(LittleBell())
# b_tower2.append(LittleBell())
# b_tower3.append(LittleBell())
# b_tower3.append(BigBell())
# b_tower1.sound()
# b_tower2.sound()
# b_tower3.sound()
# b_tower4.sound()
# b_tower3.append(BigBell())
# b_tower1.append(BigBell())
# b_tower1.append(BigBell())
# b_tower1.append(BigBell())
# b_tower3.append(LittleBell())
# b_tower1.sound()
# b_tower2.sound()
# b_tower3.sound()
# b_tower4.sound()
