def is_palindrome(data):
    if data == data[::-1]:
        return True
    else:
        return False